Hi,
I choose the Python 2 (not 3) for coding re-use of Google natural language search engine API, pls you kindly reivew NL.py.
Thanks.

Python call google NL servcie example:
https://www.google.com/search?q=1 furlong + 2.5 feet = ? meters
+++++++++++++++++++++++++
Run the App by

Python NL.py

+++++++++++++++++++++++++