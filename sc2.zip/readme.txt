Hello,
Java folder is the Java version 's App;
Python folder is the Python version 's APP;
Solution:
1. Java or Python call the Google 's natural language search engine API;
2. Java call the Rule engine;
3. Using the Lisp AI;
4. Using COBOL;
