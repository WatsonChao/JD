import urllib
import sys
import re

user_agent = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.7) Gecko/2009021910 Firefox/3.0.7'
gUrl = "http://www.google.com.hk/search?q="


def parseResult(searchStr):
    headers={'User-Agent':user_agent,}
    global gUrl
    gUrl += searchStr
    print gUrl
    html =urllib.urlopen(gUrl).read()
    

    
    if not html:
        print "Request cannot be processed"
        sys.exit(0)
    print ""
    
    o1 = open(searchStr.replace("=", "").split()[0]+searchStr.replace("=", "").split()[1]+".html",'w+')
    print >> o1,html
    print ""

ft = open('Infor.txt', 'r')   # open file
for line in ft:
   print line
   parseResult(line)
else:
   ft.close()
