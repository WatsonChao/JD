﻿Hi,
Java version, pls you kindly open the TestProject folder under Eclipse & run the APP is okay..
+++++++++++++++
Main Code is Calculator.java，

output.txt is the App 's running result file, under resource folder.

 
